
import os

import jwt
from dotenv import load_dotenv
from jwt import ExpiredSignatureError, InvalidTokenError

load_dotenv()

JWT_SECRET = os.getenv("JWT_SECRET")
JWT_ALGORITHM = "HS256"


def verify_token(token: str) -> dict:
    """
    Validate JWT and return authenticated user details.

    Expected claims:
    sub, email, department, level, iat, exp
    """

    if not JWT_SECRET:
        raise RuntimeError("JWT_SECRET is not configured")

    if not token:
        raise ValueError("JWT token is missing")

    try:
        payload = jwt.decode(
            token,
            JWT_SECRET,
            algorithms=[JWT_ALGORITHM]
        )

        required_claims = [
            "sub",
            "email",
            "department",
            "level",
            "iat",
            "exp"
        ]

        missing_claims = [
            claim for claim in required_claims
            if claim not in payload
        ]

        if missing_claims:
            raise ValueError(
                f"JWT is missing required claims: {missing_claims}"
            )

        if payload["department"] not in ["hr", "finance", "exec"]:
            raise ValueError("Invalid department in JWT")

        level = payload["level"]

        if not isinstance(level, int) or isinstance(level, bool):
            raise ValueError("Invalid access level in JWT")

        if level not in [1, 2, 3]:
            raise ValueError("Invalid access level in JWT")

        return {
            "user_id": payload["sub"],
            "email": payload["email"],
            "department": payload["department"],
            "level": level
        }

    except ExpiredSignatureError:
        raise ValueError("JWT token has expired")

    except InvalidTokenError:
        raise ValueError("Invalid JWT token")
