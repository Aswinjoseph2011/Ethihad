
import os
import shutil
from pathlib import Path

import pymupdf
import pytesseract
from PIL import Image
from dotenv import load_dotenv

from langchain_community.document_loaders import PyMuPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_google_genai import GoogleGenerativeAIEmbeddings
from langchain_chroma import Chroma


# Load environment variables
load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent
DOCS_DIR = BASE_DIR / "docs"
CHROMA_PATH = BASE_DIR / os.getenv("CHROMA_PATH", "chroma_db")

COLLECTION_NAME = "etihad_policy_docs"

# Access levels specified in the assignment
ACCESS_LEVELS = {
    "hr/leave_policy.pdf": 1,
    "hr/code_of_conduct.pdf": 1,
    "hr/performance_review.pdf": 2,
    "finance/expense_policy.pdf": 1,
    "finance/travel_reimbursement.pdf": 1,
    "exec/compensation_committee.pdf": 3,
    "exec/strategic_plan.pdf": 3,
}


def load_pdf(pdf_path: Path):
    """Extract PDF text and use OCR for scanned pages."""

    loader = PyMuPDFLoader(str(pdf_path))
    documents = loader.load()

    # Check each page and apply OCR when text extraction fails
    with pymupdf.open(str(pdf_path)) as pdf:
        for index, document in enumerate(documents):

            page_text = document.page_content.strip()

            if len(page_text) < 30:
                print(f"OCR processing: {pdf_path.name}, page {index + 1}")

                page = pdf[index]
                pix = page.get_pixmap(dpi=300, alpha=False)

                image = Image.frombytes(
                    "RGB",
                    [pix.width, pix.height],
                    pix.samples
                )

                ocr_text = pytesseract.image_to_string(image)

                if ocr_text.strip():
                    document.page_content = ocr_text

            # Use one-based page numbering
            document.metadata["page"] = index + 1

    return documents


def load_all_documents():
    """Load all PDFs and attach department and access metadata."""

    all_documents = []

    pdf_files = sorted(DOCS_DIR.rglob("*.pdf"))

    if not pdf_files:
        raise FileNotFoundError(
            f"No PDF files found inside {DOCS_DIR}"
        )

    for pdf_path in pdf_files:

        relative_path = pdf_path.relative_to(DOCS_DIR).as_posix()

        if relative_path not in ACCESS_LEVELS:
            raise ValueError(
                f"Access level not defined for: {relative_path}"
            )

        department = relative_path.split("/")[0]
        access_level = ACCESS_LEVELS[relative_path]

        print(f"Loading: {relative_path}")

        documents = load_pdf(pdf_path)

        for document in documents:
            document.metadata.update({
                "department": department,
                "access_level": access_level,
                "source_file": pdf_path.name,
            })

        all_documents.extend(documents)

    return all_documents


def create_vector_database():
    """Split documents, generate Gemini embeddings and store in ChromaDB."""

    documents = load_all_documents()

    print(f"\nTotal PDF pages loaded: {len(documents)}")

    # Chunking strategy
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=1000,
        chunk_overlap=150
    )

    chunks = text_splitter.split_documents(documents)

    if not chunks:
        raise ValueError("No text chunks were generated from the PDFs.")

    print(f"Total chunks created: {len(chunks)}")

    # Gemini embedding model
    embeddings = GoogleGenerativeAIEmbeddings(
        model=os.getenv(
            "GEMINI_EMBEDDING_MODEL",
            "gemini-embedding-2"
        )
    )

    # Rebuild the collection to avoid duplicate chunks on reruns
    if CHROMA_PATH.exists():
        shutil.rmtree(CHROMA_PATH)

    CHROMA_PATH.mkdir(parents=True, exist_ok=True)

    vector_store = Chroma.from_documents(
        documents=chunks,
        embedding=embeddings,
        collection_name=COLLECTION_NAME,
        persist_directory=str(CHROMA_PATH)
    )

    print("\nIngestion completed successfully!")
    print(f"Total chunks stored: {len(chunks)}")
    print(f"ChromaDB location: {CHROMA_PATH}")

    return vector_store


if __name__ == "__main__":
    create_vector_database()
