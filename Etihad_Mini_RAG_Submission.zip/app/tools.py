
import asyncio

from langchain_core.tools import tool


# Mock backend API 1: Employee profile
async def get_employee_profile(user_id: str):
    await asyncio.sleep(1)

    return {
        "name": "Jane Doe",
        "grade": "Senior"
    }


# Mock backend API 2: Manager information
async def get_manager_details(user_id: str):
    await asyncio.sleep(1)

    return {
        "manager": "John Smith"
    }


# Mock backend API 3: Team information
async def get_team_details(user_id: str):
    await asyncio.sleep(1)

    return {
        "team_size": 8,
        "team_name": "Platform"
    }


@tool
async def get_employee_context(user_id: str) -> dict:
    """
    Retrieve employee profile, manager information,
    and team details from backend services.

    Use this tool when a user asks personal questions
    about their employee profile, manager, or team.
    """

    profile, manager, team = await asyncio.gather(
        get_employee_profile(user_id),
        get_manager_details(user_id),
        get_team_details(user_id)
    )

    return {
        "user_id": user_id,
        "profile": profile,
        "manager": manager,
        "team": team
    }
