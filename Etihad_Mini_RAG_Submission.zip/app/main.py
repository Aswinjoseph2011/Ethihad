
import json
import logging

from fastapi import FastAPI, WebSocket, WebSocketDisconnect

from app.auth import verify_token
from app.rag import rag_app

app = FastAPI(
    title="Etihad Airways Mini RAG Chatbot",
    description="Secure department-aware RAG chatbot",
    version="1.0.0"
)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# --------------------------------------------------
# HEALTH CHECK
# --------------------------------------------------

@app.get("/")
async def health_check():
    return {
        "status": "running",
        "application": "Etihad Airways Mini RAG Chatbot"
    }


# --------------------------------------------------
# WEBSOCKET CHAT
# --------------------------------------------------

@app.websocket("/ws/chat")
async def websocket_chat(websocket: WebSocket):

    await websocket.accept()

    authenticated_user = None

    try:

        # ------------------------------------------
        # STEP 1: AUTHENTICATION
        # ------------------------------------------

        auth_message = await websocket.receive_text()

        try:
            auth_data = json.loads(auth_message)

            if auth_data.get("type") != "auth":
                raise ValueError(
                    "First message must be an authentication message"
                )

            authenticated_user = verify_token(
                auth_data.get("token")
            )

        except (ValueError, TypeError, json.JSONDecodeError) as exc:

            await websocket.send_json({
                "type": "auth_failed",
                "message": str(exc)
            })

            await websocket.close(code=1008)
            return

        except Exception:

            logger.exception("Authentication service error")

            await websocket.send_json({
                "type": "auth_failed",
                "message": "Authentication service error"
            })

            await websocket.close(code=1011)
            return

        # ------------------------------------------
        # STEP 2: AUTHENTICATION SUCCESS
        # ------------------------------------------

        await websocket.send_json({
            "type": "auth_success",
            "user_id": authenticated_user["user_id"],
            "department": authenticated_user["department"],
            "level": authenticated_user["level"]
        })

        logger.info(
            "Authenticated user: %s",
            authenticated_user["user_id"]
        )

        # ------------------------------------------
        # STEP 3: CHAT MESSAGE LOOP
        # ------------------------------------------

        while True:

            message = await websocket.receive_text()

            try:
                message_data = json.loads(message)

                if message_data.get("type") != "message":

                    await websocket.send_json({
                        "type": "error",
                        "message": "Unsupported message type"
                    })

                    continue

                question = message_data.get("text", "").strip()

                if not question:

                    await websocket.send_json({
                        "type": "error",
                        "message": "Message cannot be empty"
                    })

                    continue

                # ----------------------------------
                # STEP 4: INITIALIZE LANGGRAPH STATE
                # ----------------------------------

                initial_state = {
                    "question": question,
                    "documents": [],
                    "answer": "",
                    "needs_retrieval": False,
                    "department": authenticated_user["department"],
                    "level": authenticated_user["level"],
                    "user_id": authenticated_user["user_id"]
                }

                # ----------------------------------
                # STEP 5: REAL-TIME GEMINI STREAMING
                # ----------------------------------

                async for event in rag_app.astream(
                    initial_state,
                    stream_mode="custom"
                ):

                    if isinstance(event, dict):

                        chunk_text = event.get("text", "")

                        if chunk_text:

                            await websocket.send_json({
                                "type": "stream",
                                "text": chunk_text
                            })

                # ----------------------------------
                # STEP 6: COMPLETION
                # ----------------------------------

                await websocket.send_json({
                    "type": "done"
                })

            except json.JSONDecodeError:

                await websocket.send_json({
                    "type": "error",
                    "message": "Invalid JSON message"
                })

            except Exception:

                logger.exception("Chat processing failed")

                await websocket.send_json({
                    "type": "error",
                    "message": (
                        "Unable to process your question. "
                        "Please try again."
                    )
                })

                # Keep the WebSocket connection open.

    except WebSocketDisconnect:

        logger.info(
            "WebSocket disconnected: %s",
            authenticated_user["user_id"]
            if authenticated_user else "Unauthenticated user"
        )

    except Exception:

        logger.exception("Unexpected WebSocket error")

        try:
            await websocket.close(code=1011)
        except Exception:
            pass
