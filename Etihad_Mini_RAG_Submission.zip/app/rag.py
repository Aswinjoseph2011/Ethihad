
import os
from typing import TypedDict, List

from dotenv import load_dotenv
from langchain_core.documents import Document
from langchain_google_genai import (
    ChatGoogleGenerativeAI,
    GoogleGenerativeAIEmbeddings
)
from langchain_chroma import Chroma
from langgraph.graph import StateGraph, END
import asyncio
from app.tools import get_employee_context
from langgraph.config import get_stream_writer
load_dotenv()

# --------------------------------------------------
# CONFIGURATION
# --------------------------------------------------

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

CHROMA_PATH = os.path.join(
    BASE_DIR,
    os.getenv("CHROMA_PATH", "./chroma_db").replace("./", "")
)

COLLECTION_NAME = "etihad_policy_docs"


# --------------------------------------------------
# INITIALIZE GEMINI
# --------------------------------------------------

llm = ChatGoogleGenerativeAI(
    model=os.getenv("GEMINI_MODEL"),
    max_retries=2,
    timeout=60
)

embeddings = GoogleGenerativeAIEmbeddings(
    model=os.getenv("GEMINI_EMBEDDING_MODEL")
)


# --------------------------------------------------
# CONNECT TO CHROMADB
# --------------------------------------------------

vectorstore = Chroma(
    collection_name=COLLECTION_NAME,
    persist_directory=CHROMA_PATH,
    embedding_function=embeddings
)


# --------------------------------------------------
# LANGGRAPH STATE
# --------------------------------------------------

class AgentState(TypedDict):
    question: str
    documents: List[Document]
    answer: str
    needs_retrieval: bool
    department: str
    level: int
    user_id: str


# --------------------------------------------------
# NODE 1: DECIDE RETRIEVAL
# --------------------------------------------------

def decide_retrieval(state: AgentState) -> dict:
    """
    Decide whether the question requires
    policy document retrieval.
    """

    question = state["question"].lower()

    retrieval_keywords = [
        "policy",
        "leave",
        "expense",
        "travel",
        "reimbursement",
        "performance",
        "conduct",
        "compensation",
        "strategic",
        "what",
        "how",
        "explain",
        "describe",
        "entitled"
    ]

    needs_retrieval = any(
        keyword in question
        for keyword in retrieval_keywords
    )

    return {
        "needs_retrieval": needs_retrieval
    }


# --------------------------------------------------
# NODE 2: RETRIEVE DOCUMENTS WITH RBAC
# --------------------------------------------------

def retrieve_documents(state: AgentState) -> dict:
    """
    Retrieve policy documents using department
    and access-level restrictions.
    """

    department = state["department"]
    level = state["level"]

    access_filter = {
        "$and": [
            {
                "access_level": {
                    "$lte": level
                }
            },
            {
                "$or": [
                    {
                        "department": {
                            "$eq": "hr"
                        }
                    },
                    {
                        "department": {
                            "$eq": department
                        }
                    }
                ]
            }
        ]
    }

    results = vectorstore.similarity_search(
        query=state["question"],
        k=4,
        filter=access_filter
    )

    return {
        "documents": results
    }


# --------------------------------------------------
# HELPER: NORMALIZE GEMINI RESPONSE
# --------------------------------------------------

def extract_response_text(response) -> str:
    """
    Convert Gemini response content into plain text.
    """

    content = response.content

    if isinstance(content, str):
        return content

    if isinstance(content, list):
        return "\n".join(
            block.get("text", "")
            for block in content
            if isinstance(block, dict)
        )

    return str(content)


# --------------------------------------------------
# NODE 3: GENERATE ANSWER
# --------------------------------------------------


async def generate_answer(state: AgentState) -> dict:
    """
    Generate responses using Gemini token streaming.

    Streams each generated text chunk through LangGraph.
    """

    question = state["question"]
    documents = state.get("documents", [])

    writer = get_stream_writer()

    employee_keywords = [
        "my profile",
        "my manager",
        "my team",
        "my grade",
        "who is my manager",
        "team size",
        "team name",
        "my employee details"
    ]

    is_employee_question = any(
        keyword in question.lower()
        for keyword in employee_keywords
    )

    # ----------------------------------------------
    # EMPLOYEE CONTEXT
    # ----------------------------------------------

    if is_employee_question:

        employee_context = await get_employee_context.ainvoke({
            "user_id": state["user_id"]
        })

        prompt = f"""
You are an internal Etihad Airways assistant.

Answer using only the employee information below.
Do not invent employee details.

Employee Context:
{employee_context}

Question:
{question}

Answer:
"""

    # ----------------------------------------------
    # POLICY CONTEXT
    # ----------------------------------------------

    elif documents:

        context = "\n\n".join(
            [
                f"Source: {doc.metadata.get('source_file', 'Unknown')}\n"
                f"Page: {doc.metadata.get('page', 'Unknown')}\n"
                f"Content: {doc.page_content}"
                for doc in documents
            ]
        )

        prompt = f"""
You are an internal Etihad Airways policy assistant.

Answer using only the provided policy context.

Rules:
- Do not invent policy details.
- If information is unavailable, clearly say so.
- Keep the answer clear and concise.
- Mention the source document when relevant.

Policy Context:
{context}

Question:
{question}

Answer:
"""

    # ----------------------------------------------
    # GENERAL QUESTIONS
    # ----------------------------------------------

    else:

        prompt = f"""
You are an internal Etihad Airways assistant.

Answer general questions briefly.
Do not invent internal company policy information.

Question:
{question}

Answer:
"""

    # ----------------------------------------------
    # REAL GEMINI TOKEN STREAMING
    # ----------------------------------------------

    answer_parts = []

    async for chunk in llm.astream(prompt):

        content = chunk.content

        if isinstance(content, str):
            text = content

        elif isinstance(content, list):
            text = "".join(
                block.get("text", "")
                for block in content
                if isinstance(block, dict)
            )

        else:
            text = ""

        if text:
            answer_parts.append(text)

            # Send each generated chunk to LangGraph
            writer({"text": text})

    return {
        "answer": "".join(answer_parts)
    }

# --------------------------------------------------
# ROUTING
# --------------------------------------------------

def should_retrieve(state: AgentState) -> str:

    if state["needs_retrieval"]:
        return "retrieve"

    return "generate"


# --------------------------------------------------
# BUILD LANGGRAPH WORKFLOW
# --------------------------------------------------

workflow = StateGraph(AgentState)

workflow.add_node("decide", decide_retrieval)
workflow.add_node("retrieve", retrieve_documents)
workflow.add_node("generate", generate_answer)

workflow.set_entry_point("decide")

workflow.add_conditional_edges(
    "decide",
    should_retrieve,
    {
        "retrieve": "retrieve",
        "generate": "generate"
    }
)

workflow.add_edge("retrieve", "generate")
workflow.add_edge("generate", END)

rag_app = workflow.compile()


# --------------------------------------------------
# MAIN FUNCTION
# --------------------------------------------------

def ask_question(
    question: str,
    department: str,
    level: int,
    user_id: str
) -> dict:

    initial_state = {
        "question": question,
        "documents": [],
        "answer": "",
        "needs_retrieval": False,
        "department": department,
        "level": level,
        "user_id": user_id
    }

    return rag_app.invoke(initial_state)
