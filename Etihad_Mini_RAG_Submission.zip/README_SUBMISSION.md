# Etihad Airways – Mini RAG Chatbot Backend

## 1. Project Overview

A secure, department-aware Retrieval-Augmented Generation (RAG) chatbot built using Python, FastAPI, LangChain, LangGraph, Google Gemini and ChromaDB.

Features:
- PDF ingestion and text extraction with OCR fallback.
- Document chunking and vector embeddings.
- Department-level and access-level document security.
- Real-time response streaming through WebSockets.
- JWT-based authentication.
- Asynchronous employee-context tools.

## 2. Technology Stack

- Python 3.12
- FastAPI and WebSockets
- LangChain and LangGraph
- Google Gemini LLM and embeddings
- ChromaDB
- PyMuPDF and Tesseract OCR
- PyJWT
- asyncio

## 3. Project Structure

```text
app/
  main.py
  auth.py
  ingestion.py
  rag.py
  tools.py
docs/
  hr/
  finance/
  exec/
miniragchatbot/
  mint_tokens.py
  test_client.html
.env
.env.example
.gitignore
requirements.txt
README_SUBMISSION.md


## 4. Setup Instructions

Requirements: Python 3.12, Gemini API key and Tesseract OCR.

Create and activate the environment:

    python3.12 -m venv venv
    source venv/bin/activate
    pip install -r requirements.txt

Configure `.env` using `.env.example`.

On macOS, install Tesseract using MacPorts:

    sudo port install tesseract
    sudo port install tesseract-eng

## 5. Document Ingestion

Run:

    python app/ingestion.py

The pipeline loads PDFs, extracts text using PyMuPDF, applies Tesseract OCR when needed, splits text into chunks and stores Gemini embeddings in ChromaDB.

Chunk size: 1000 characters.
Chunk overlap: 150 characters.
Collection: etihad_policy_docs.

Each chunk stores department, access_level, source_file and page metadata.

Note: Running ingestion rebuilds the ChromaDB directory.

## 6. Authentication

Generate test JWT tokens:

    python miniragchatbot/mint_tokens.py

Test users:

| User ID | Department | Level |
|---|---|---|
| emp-001 | HR | 1 |
| mgr-002 | HR | 2 |
| exec-003 | Executive | 3 |

JWT authentication uses HS256.

## 7. Start the Application

    uvicorn app.main:app --reload

Health endpoint: http://127.0.0.1:8000/

WebSocket endpoint: ws://127.0.0.1:8000/ws/chat

Open `miniragchatbot/test_client.html` in a browser to test the chatbot.

## 8. WebSocket Protocol

First, authenticate:

    {"type":"auth","token":"<jwt>"}

Successful authentication returns `auth_success` with user_id, department and level.

A chat request:

    {"type":"message","text":"How many annual leave days are available?"}

The server sends progressive `stream` messages followed by `done`.

Invalid authentication returns `auth_failed` and closes the connection.

## 9. Retrieval and Role-Based Access Control

Authorization is applied during ChromaDB retrieval.

Policy:

    access_level <= user.level
    AND
    (department == "hr" OR department == user.department)

Users can access their own department's documents. HR documents are accessible to all authenticated users. Access levels restrict documents according to the user's level.

## 10. LangGraph Workflow

The workflow contains three nodes:

1. Decide: determines whether document retrieval is required.
2. Retrieve: searches ChromaDB using the authenticated user's access permissions.
3. Generate: generates the response using Gemini and available context.

Custom streaming events are forwarded through the FastAPI WebSocket connection.

## 11. Employee Context Tool

The asynchronous employee-context tool retrieves employee profile, manager details and team details.

The three mock API calls execute concurrently using `asyncio.gather()`.

Verified execution time: approximately 1.03 seconds.

## 12. Error Handling

- Invalid or tampered JWT: authentication rejected.
- Missing authentication: authentication rejected.
- Invalid message format: error response.
- Empty question: error response.
- LLM or tool failure: user-facing error while keeping the authenticated session open where possible.

## 13. Testing Results

| Test | Result |
|---|---|
| HR Level 1 cannot access Level 2 performance review | Passed |
| HR Level 2 can access performance review | Passed |
| Executive can access strategic plan | Passed |
| Executive cannot access finance expense policy | Passed |
| Employee context retrieval | Passed |
| Parallel execution | Passed — 1.03 seconds |
| Tampered JWT rejection | Passed |
| Gemini response streaming | Passed |

## 14. Design Decisions and Trade-offs

- ChromaDB provides local vector storage and LangChain integration.
- Gemini is used for text generation and embeddings.
- Chunking uses 1000 characters with 150-character overlap.
- Tesseract OCR supports scanned PDFs but adds an external dependency.
- Mock employee APIs demonstrate asynchronous orchestration without external enterprise services.
- RBAC is enforced during vector retrieval instead of relying only on prompt instructions.

